var currentTab;
var currentBookmark;


function logTabs(windowInfo) {
	
  for (let tabInfo of windowInfo.tabs) {
    console.log(tabInfo.url);
	
	if (tabInfo.active) {

	var lastURL = tabInfo.url;
    
		} 
  }
  
 var encodedurl = window.btoa(lastURL);
 var popupURL = "https://www.notecabi.net/popupversion.php?q="+encodedurl;

  var creating = browser.windows.create({
    url: popupURL,
    type: "popup",
    height: 730,
    width: 560
  });
  
}

function onError(error) {
  console.log(`Error: ${error}`);
}


function openPage() {

	var getting = browser.windows.getCurrent({populate: true});
    getting.then(logTabs, onError);

/**
	browser.tabs.create({
    url: "https://developer.mozilla.org"
  }  
  );
  
  **/
    
}

browser.browserAction.onClicked.addListener(openPage);